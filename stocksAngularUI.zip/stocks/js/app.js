'use strict';

angular.module('myStocksApp', [])
  .controller('StocksController', function($scope, $http){
    $scope.$watch('search', function() {
      fetch();
    });

    $scope.search = "TELCO";

    function fetch(){
      $http.get("http://localhost:1337/stocks/")
      .then(function(response){ 
        console.log(response);
        $scope.details = response.data; });
    }
  });
