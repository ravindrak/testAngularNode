module.exports = {
  getStocks: function(next) {
    Stocks.find({'companyName':'CAC 40'}).exec(function(err, stocks) {
      if(err) throw err;
      next(stocks);
    });
  },
  addStock: function(stockVal, next) {
    Stocks.create({value: stockVal}).exec(function(err, stock) {
      if(err) throw err;
      next(stock);
    });
  },
  updateStock: function(id, stock, next) {
    Stocks.update({id:id},{'symbol':stock.symbol, 'companyName':stock.companyName, 'value':stock.value}).exec(function(err, stock) {
      if(err) throw err;
      next(stock);
    });
  },
  removeStock: function(stockVal, next) {
    Stocks.destroy({value: stockVal}).exec(function(err, stock) {
      if(err) throw err;
      next(stock);
    });
  }
};