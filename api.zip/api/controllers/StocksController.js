/**
 * StocksController
 *
 * @description :: Server-side logic for managing stocks
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {

	findStock: function(req, res){
		var symbol = req.param('symbol');
		Stocks.findOne({'symbol':symbol})
		.exec(function(err, stockFound){
			if (err) {
                return res.json({
                    error: err
                });
            }
            if (stockFound === undefined) {
                    return res.notFound();
                } else{
					return res.json(stockFound);
                    /*return res.json({
                        notFound: false,
                        stockData: stockFound
                    });*/
                }
		})
	},

	getStocks: function(req, res) {
        StocksService.getStocks(function(stocks) {
            res.json(stocks);
        });
    },
	
    addStock: function(req, res) {
		var symbol = req.param('symbol');
		var company = req.param('companyName');
		var value = req.param('stockValue');
		var rowId = '';

        StocksService.addStock(rowId, {'symbol':symbol, 'companyName':company, 'value':value}, function(success) {
            res.json(success);
        });
    },
	
	update: function(req, res){
		var id = req.param('id');
		var symbol = req.param('symbol');
		var company = req.param('companyName');
		var value = req.param('value');
		
		StocksService.updateStock(id, {'symbol':symbol, 'companyName':company, 'value':value}, function(success) {
            res.json(success);
        });
	},
	
    removeStock: function(req, res) {
       var stockVal = (req.body.value) ? req.body.value : undefined
        StocksService.removeStock(stockVal, function(success) {
            res.json(success);
        });
    },
	
	
};

